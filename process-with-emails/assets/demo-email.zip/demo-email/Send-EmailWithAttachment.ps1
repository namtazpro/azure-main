<#
.SYNOPSIS
    Creates a new Outlook email, attaches an existing email (by message-id) as an .eml file, and sends it.

.DESCRIPTION
    Connects to Microsoft Graph using a delegated (interactive) Connect-MgGraph login. Downloads the
    original message identified by -MessageId as MIME (.eml), attaches it to a brand-new email addressed
    to -To with the supplied -Message body, previews all details, and sends only after you confirm.

.PARAMETER MessageId
    The Graph message-id of the original email to attach (e.g. the value returned by Find-EmailMessageId.ps1).

.PARAMETER To
    The recipient email address of the new email.

.PARAMETER Message
    The body text of the new email.

.PARAMETER Subject
    Optional subject for the new email. Defaults to "Fwd: <original subject>".

.EXAMPLE
    .\Send-EmailWithAttachment.ps1 -MessageId "AAMk..." -To "jane@contoso.com" -Message "Please see attached."

.NOTES
    Requires the Microsoft.Graph.Authentication module and the User.Read + Mail.Read + Mail.Send delegated scopes.
    The original email is attached inline as base64; single-request attachments are limited to ~3 MB.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$MessageId,

    [Parameter(Mandatory)]
    [ValidatePattern('^[^@\s]+@[^@\s]+\.[^@\s]+$')]
    [string]$To,

    [Parameter(Mandatory)]
    [string]$Message,

    [string]$Subject
)

$ErrorActionPreference = 'Stop'

function Ensure-GraphConnection {
    param([string[]]$Scopes)

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    $context = $null
    try { $context = Get-MgContext } catch { $context = $null }

    $hasScopes = $false
    if ($context) {
        $hasScopes = -not ($Scopes | Where-Object { $_ -notin $context.Scopes })
    }

    $hasUsableSession = $false
    if ($context -and $hasScopes) {
        try {
            Invoke-MgGraphRequest -Method GET -Uri '/v1.0/me?$select=id' | Out-Null
            $hasUsableSession = $true
        }
        catch {
            Write-Warning "The existing Microsoft Graph login is not usable. Sign in again."
            Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        }
    }

    if (-not $hasUsableSession) {
        Write-Host "Microsoft Graph login required (scopes: $($Scopes -join ', '))." -ForegroundColor Cyan
        Connect-MgGraph -Scopes $Scopes -ContextScope Process | Out-Null
    }
}

function Confirm-GraphAccount {
    $context = Get-MgContext
    $profile = Invoke-MgGraphRequest -Method GET -Uri '/v1.0/me?$select=displayName,mail,userPrincipalName'
    $email = if ($profile.mail) { $profile.mail } else { $profile.userPrincipalName }

    Write-Host "`nSigned in to Microsoft Graph as:" -ForegroundColor Cyan
    Write-Host ("  Name   : {0}" -f $profile.displayName)
    Write-Host ("  Email  : {0}" -f $email) -ForegroundColor White
    Write-Host ("  Tenant : {0}" -f $context.TenantId)

    $confirm = Read-Host "Use this mailbox? (y/N)"
    if ($confirm -notmatch '^(y|yes)$') {
        throw "Wrong Microsoft Graph account. Run Disconnect-MgGraph, then run this script again and sign in with the correct email."
    }
}

try {
    Ensure-GraphConnection -Scopes @('User.Read', 'Mail.Read', 'Mail.Send')
    Confirm-GraphAccount

    # Fetch original message metadata to build a sensible default subject and preview.
    Write-Host "Retrieving original message..." -ForegroundColor Cyan
    $original = Invoke-MgGraphRequest -Method GET -Uri ('/v1.0/me/messages/' + $MessageId + '?$select=id,subject,from,receivedDateTime')

    if ([string]::IsNullOrWhiteSpace($Subject)) {
        $Subject = "Fwd: $($original.subject)"
    }

    # Download the original message as MIME (.eml) and base64-encode it for a fileAttachment.
    Write-Host "Downloading original email as .eml (MIME)..." -ForegroundColor Cyan
    $tempMimePath = Join-Path ([System.IO.Path]::GetTempPath()) ("graph-message-{0}.eml" -f [guid]::NewGuid())
    try {
        Invoke-MgGraphRequest -Method GET -Uri ('/v1.0/me/messages/' + $MessageId + '/$value') -OutputFilePath $tempMimePath | Out-Null
        $bytes = [System.IO.File]::ReadAllBytes($tempMimePath)
    }
    finally {
        Remove-Item -LiteralPath $tempMimePath -Force -ErrorAction SilentlyContinue
    }

    $contentBytes = [System.Convert]::ToBase64String($bytes)
    $sizeKb = [math]::Round($bytes.Length / 1KB, 1)

    $safeName = ($original.subject -replace '[\\/:*?"<>|]', '_')
    if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'original' }
    $attachmentName = "$safeName.eml"

    if ($bytes.Length -gt 3MB) {
        Write-Warning "The original email is $sizeKb KB, which may exceed the ~3 MB inline attachment limit and could fail to send."
    }

    # Build the new message payload.
    $newMessage = @{
        message = @{
            subject      = $Subject
            body         = @{
                contentType = 'Text'
                content     = $Message
            }
            toRecipients = @(
                @{ emailAddress = @{ address = $To } }
            )
            attachments  = @(
                @{
                    '@odata.type' = '#microsoft.graph.fileAttachment'
                    name          = $attachmentName
                    contentType   = 'message/rfc822'
                    contentBytes  = $contentBytes
                }
            )
        }
        saveToSentItems = $true
    }

    # Preview before sending.
    Write-Host "`n========================= NEW EMAIL PREVIEW =========================" -ForegroundColor Green
    Write-Host ("To         : {0}" -f $To)
    Write-Host ("Subject    : {0}" -f $Subject)
    Write-Host ("Attachment : {0} ({1} KB, from original '{2}')" -f $attachmentName, $sizeKb, $original.subject)
    Write-Host "-------------------------------- Body --------------------------------"
    Write-Host $Message
    Write-Host "======================================================================`n" -ForegroundColor Green

    $confirm = Read-Host "Send this email now? (y/N)"
    if ($confirm -notmatch '^(y|yes)$') {
        Write-Host "Cancelled. Email was not sent." -ForegroundColor Yellow
        return
    }

    Write-Host "Sending..." -ForegroundColor Cyan
    Invoke-MgGraphRequest -Method POST -Uri "/v1.0/me/sendMail" -Body $newMessage | Out-Null

    Write-Host "Email sent successfully to $To with '$attachmentName' attached." -ForegroundColor Green
}
catch {
    Write-Error "Failed to send email: $($_.Exception.Message)"
    exit 1
}
