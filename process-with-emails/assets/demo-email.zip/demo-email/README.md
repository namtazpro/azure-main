# Outlook Email Forward-as-Attachment Scripts (Microsoft Graph)

Two PowerShell scripts that use the **Microsoft.Graph PowerShell SDK** (delegated,
interactive `Connect-MgGraph` login) against your own mailbox (`/me`):

1. **`Find-EmailMessageId.ps1`** — search your mailbox by subject, confirm the email content,
   and return its Graph **message-id**.
2. **`Send-EmailWithAttachment.ps1`** — attach that original email (as an `.eml` file) to a
   brand-new email, preview it, and send after confirmation.

## Prerequisites

- PowerShell 7+ (or Windows PowerShell 5.1).
- The Microsoft Graph SDK modules:
  ```powershell
  Install-Module Microsoft.Graph.Authentication -Scope CurrentUser
  ```
- On first run you will be prompted to sign in and **consent** to the delegated scopes:
  - `User.Read` (both scripts, to display and confirm the signed-in account)
  - `Mail.Read` (script 1 and 2)
  - `Mail.Send` (script 2)

The scripts sign you in interactively via `Connect-MgGraph`. If you are already connected with
the required scopes, the existing session is reused. Before either script accesses mail, it displays
the name, email address, and tenant returned by Microsoft Graph `/me` and asks you to confirm the
mailbox. Both scripts use this same Graph identity.

If the displayed email is wrong, answer `n`, then switch accounts and rerun the script:

```powershell
Disconnect-MgGraph
```

## Usage

### Step 1 — find the message-id

```powershell
.\Find-EmailMessageId.ps1 -Subject "Quarterly report"
```

- Prompts for a subject if `-Subject` is omitted.
- Lists matches when more than one is found and lets you pick one.
- Shows the email preview (From / To / Date / Subject / body) for confirmation.
- On `y`, prints the **message-id** and copies it to the clipboard.

Optional: `-Top <n>` limits the number of search results (default 10).

### Step 2 — send a new email with the original attached

```powershell
.\Send-EmailWithAttachment.ps1 `
    -MessageId "<paste the id from step 1>" `
    -To "jane@contoso.com" `
    -Message "Please see the original email attached."
```

- Downloads the original email as MIME (`.eml`) and attaches it to a new message.
- `-Subject` is optional; defaults to `Fwd: <original subject>`.
- Prints a full preview (To / Subject / attachment name+size / body).
- Sends only after you confirm with `y`.

## How the attachment works

The original message is retrieved via `GET /me/messages/{id}/$value` (its raw MIME), base64-encoded,
and added to the new message as a `#microsoft.graph.fileAttachment` with content type
`message/rfc822` and an `.eml` file name. The new email is sent with `POST /me/sendMail`.

## Notes & limitations

- `$search` (used for subject matching) requires the `ConsistencyLevel: eventual` header, which the
  script sets automatically.
- The `.eml` attachment is sent inline as base64. Single-request attachments are limited to about
  **3 MB**; larger originals may fail to send (the script warns you when this is likely).
