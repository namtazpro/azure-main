<#
.SYNOPSIS
    Finds an Outlook email in the signed-in user's mailbox by subject and returns its Graph message-id.

.DESCRIPTION
    Connects to Microsoft Graph using a delegated (interactive) Connect-MgGraph login, searches the
    signed-in user's mailbox (/me) for messages matching a subject, lets you pick one when several
    match, displays the email content so you can confirm it is the right one, and outputs the
    message-id (also copying it to the clipboard) so it can be passed to Send-EmailWithAttachment.ps1.

.PARAMETER Subject
    The subject text to search for. If omitted you will be prompted.

.PARAMETER Top
    Maximum number of matching messages to retrieve. Default 10.

.EXAMPLE
    .\Find-EmailMessageId.ps1 -Subject "Quarterly report"

.NOTES
    Requires the Microsoft.Graph.Authentication module and the User.Read + Mail.Read delegated scopes.
#>
[CmdletBinding()]
param(
    [string]$Subject,
    [int]$Top = 10
)

$ErrorActionPreference = 'Stop'

function Ensure-GraphConnection {
    param([string[]]$Scopes)

    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop

    $context = $null
    try { $context = Get-MgContext } catch { $context = $null }

    $hasScopes = $false
    if ($context) {
        $hasScopes = -not ($Scopes | Where-Object { $_ -notin $context.Scopes })
    }

    $hasUsableSession = $false
    if ($context -and $hasScopes) {
        try {
            Invoke-MgGraphRequest -Method GET -Uri '/v1.0/me?$select=id' | Out-Null
            $hasUsableSession = $true
        }
        catch {
            Write-Warning "The existing Microsoft Graph login is not usable. Sign in again."
            Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        }
    }

    if (-not $hasUsableSession) {
        Write-Host "Microsoft Graph login required (scopes: $($Scopes -join ', '))." -ForegroundColor Cyan
        Connect-MgGraph -Scopes $Scopes -ContextScope Process | Out-Null
    }
}

function Confirm-GraphAccount {
    $context = Get-MgContext
    $profile = Invoke-MgGraphRequest -Method GET -Uri '/v1.0/me?$select=displayName,mail,userPrincipalName'
    $email = if ($profile.mail) { $profile.mail } else { $profile.userPrincipalName }

    Write-Host "`nSigned in to Microsoft Graph as:" -ForegroundColor Cyan
    Write-Host ("  Name   : {0}" -f $profile.displayName)
    Write-Host ("  Email  : {0}" -f $email) -ForegroundColor White
    Write-Host ("  Tenant : {0}" -f $context.TenantId)

    $confirm = Read-Host "Use this mailbox? (y/N)"
    if ($confirm -notmatch '^(y|yes)$') {
        throw "Wrong Microsoft Graph account. Run Disconnect-MgGraph, then run this script again and sign in with the correct email."
    }
}

try {
    Ensure-GraphConnection -Scopes @('User.Read', 'Mail.Read')
    Confirm-GraphAccount

    if ([string]::IsNullOrWhiteSpace($Subject)) {
        $Subject = Read-Host "Enter the subject (or part of it) to search for"
    }
    if ([string]::IsNullOrWhiteSpace($Subject)) {
        throw "A subject is required to search."
    }

    Write-Host "Searching mailbox for messages with subject containing '$Subject'..." -ForegroundColor Cyan

    # Use $search (KQL) for flexible subject matching. Requires ConsistencyLevel: eventual.
    $escaped = $Subject.Replace('"', '\"')
    $searchClause = '$search="subject:' + $escaped + '"'
    $selectClause = '$select=id,subject,from,toRecipients,receivedDateTime,bodyPreview'
    $uri = '/v1.0/me/messages?' + $searchClause + '&$top=' + $Top + '&' + $selectClause

    $response = Invoke-MgGraphRequest -Method GET -Uri $uri -Headers @{ 'ConsistencyLevel' = 'eventual' }
    $messages = @($response.value)

    if ($messages.Count -eq 0) {
        Write-Host "No messages found matching '$Subject'." -ForegroundColor Yellow
        return
    }

    # Present a selection list when there is more than one match.
    $selected = $null
    if ($messages.Count -eq 1) {
        $selected = $messages[0]
    }
    else {
        Write-Host "`nFound $($messages.Count) matching messages:`n" -ForegroundColor Green
        for ($i = 0; $i -lt $messages.Count; $i++) {
            $m = $messages[$i]
            $fromAddr = $m.from.emailAddress.address
            "{0,3}. [{1:yyyy-MM-dd HH:mm}] {2}  <{3}>" -f ($i + 1), [datetime]$m.receivedDateTime, $m.subject, $fromAddr | Write-Host
        }
        do {
            $choice = Read-Host "`nSelect a message number (1-$($messages.Count)), or 'q' to quit"
            if ($choice -eq 'q') { return }
        } until (($choice -as [int]) -ge 1 -and ($choice -as [int]) -le $messages.Count)
        $selected = $messages[[int]$choice - 1]
    }

    # Fetch the full body of the chosen message for confirmation.
    $full = Invoke-MgGraphRequest -Method GET -Uri ('/v1.0/me/messages/' + $selected.id + '?$select=id,subject,from,toRecipients,receivedDateTime,body')

    $toList = ($full.toRecipients | ForEach-Object { $_.emailAddress.address }) -join '; '
    $bodyText = $full.body.content
    if ($full.body.contentType -eq 'html') {
        # Strip tags for a readable console preview.
        $bodyText = [System.Text.RegularExpressions.Regex]::Replace($bodyText, '<[^>]+>', '')
        $bodyText = [System.Net.WebUtility]::HtmlDecode($bodyText)
    }
    $bodyText = $bodyText.Trim()
    if ($bodyText.Length -gt 2000) { $bodyText = $bodyText.Substring(0, 2000) + "`n... [truncated]" }

    Write-Host "`n============================ EMAIL PREVIEW ============================" -ForegroundColor Green
    Write-Host ("From    : {0} <{1}>" -f $full.from.emailAddress.name, $full.from.emailAddress.address)
    Write-Host ("To      : {0}" -f $toList)
    Write-Host ("Date    : {0}" -f ([datetime]$full.receivedDateTime))
    Write-Host ("Subject : {0}" -f $full.subject)
    Write-Host "----------------------------------------------------------------------"
    Write-Host $bodyText
    Write-Host "======================================================================`n" -ForegroundColor Green

    $confirm = Read-Host "Is this the correct email? (y/N)"
    if ($confirm -notmatch '^(y|yes)$') {
        Write-Host "Cancelled. No message-id returned." -ForegroundColor Yellow
        return
    }

    $messageId = $full.id
    try { Set-Clipboard -Value $messageId; $clip = " (copied to clipboard)" } catch { $clip = "" }

    Write-Host "`nMessage-Id${clip}:" -ForegroundColor Cyan
    Write-Host $messageId -ForegroundColor White

    # Emit the id to the pipeline as the script's return value.
    return $messageId
}
catch {
    Write-Error "Failed to find message-id: $($_.Exception.Message)"
    exit 1
}
